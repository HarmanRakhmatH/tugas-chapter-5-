// cara 1
// const add = (n1, n2) => {
//     return n1 + n2
// }
// const substract = (n1, n2) => {
//     return n1 - n2
// }
// const multiply = (n1, n2) => {
//     return n1 * n2
// }
// const divide = (n1, n2) => {
//     return n1 / n2
// }

// module.exports = { add, substract, multiply, divide }

// cara 2

exports.add = (n1, n2) => {
    return n1 + n2
}
exports.substract = (n1, n2) => {
    return n1 - n2
}
exports.multiply = (n1, n2) => {
    return n1 * n2
}
exports.divide = (n1, n2) => {
    return n1 / n2
}
