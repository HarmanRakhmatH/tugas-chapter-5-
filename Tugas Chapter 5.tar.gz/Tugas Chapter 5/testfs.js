
// const path = require('path');

// const { json } = require('stream/consumers');


// const cpuInfo = os.cpus();
// var obj = {
//     table: []
// };


// obj.table.push(cpuInfo);

// var json = JSON.stringify(obj);

// fs.writeFile('tugaschapter5.json', json, 'utf-8', callback);

// percobaan ke 2 failure
// fs.writeFile('tugaschapter5.json', "ini spesification/n", (err) => {
//     if (err) console.log(err)
//     // console.log(`${os.cpus()}`)
// })
const os = require('os');
const { json } = require('stream/consumers');
let cpuInfo = os.cpus();

// percobaan ke 3  failure 

// fs.writeFile('tugaschapter5.json', cpuInfo, (err) => {
//     if (err) (console.log(err))
//     console.log(cpuInfo)
//     // console.log(`${os.cpus()}`)
//     // console.log(data.toJSON)
//     // console.log(data)// dapetnya buffer 
//     // let osCpu = os.cpus()
//     // console.log(osCpu)

// })

// percobaan ke empat failure
// const fs = require('fs');
// // let jsonFile = require('jsonfile');
// for (i = os.cpus(); i < 1; i++) {
//     fs.writeFile('loop.json', "id :" + i, (err) => {
//         if (err) (console.log(err))
//     });
// }


// percobaan ke lima  success 
// var fs = require('fs');

// var data = { cpuInfo }
// data.table = []
// for (i = 0; i < 1; i++) {

//     // var obj = { // var obj tidak terpakai tidak apa apa hanya menghasilkan array akhir index array  kasih tanda comment
//     //     id: i,
//     //     square: i * 1
//     // }

//     // data.table.push(obj) // data.table.push(obj) untuk menghasilkan array di akhir index dari id: , square  , tidak terpakai tidak apa kasih tanda comment
// }
// fs.writeFile("input.json", JSON.stringify(data), (err) => {
//     if (err) throw err;
//     console.log("complete");
// }
// );


// percobaan ke enam success

const fs = require('fs');

let data = { cpuInfo };

fs.writeFile('infocpu.json', JSON.stringify(data), function (err) {
    if (err) (console.log(err))
    console.log("complete")
})


fs.readFile('infocpu.json', (err, data) => {
    if (err) (console.log(err))
    console.log("read info cpu", data.toString())
})