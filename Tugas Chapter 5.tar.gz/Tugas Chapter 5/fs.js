const fs = require('fs')


// fs.writeFile('writeFile.txt', "halo kita lagi belajar node js", (err) => {
//     if (err) console.log(err)
// })


fs.readFile('writeFile.txt', (err, data) => {
    if (err) console.log(err)
    // console.log(data)// dapetnya buffer 
    // console.log(data.toString())
})



fs.readFile("writeFile.txt", "utf-8", (err, data) => {
    if (err) (console.log(err))
    // console.log(data)
})



fs.appendFile('writeFile.txt', "\nTambahan Kedua", (err) => {  // tambahan \n new line untuk menmabah enter kebawah 
    if (err) (console.log(err))
    // console.log(data)
})


// function test(a, b, c) {
//     const a = a
//     const b = b
//     const c = c(c => {
//         return c;
//     }
// }